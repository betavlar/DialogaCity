To deploy these TTS voice skins (assume they are already extracted), 
your current working directory should look like this:

:~$ ls -1
voices
README.txt
 
Then simply push the voice skins into the following location:

adb push voices /sdcard/Android/data/<NAMESPACE>/files/voices-download
